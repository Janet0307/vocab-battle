
# Vocabulary Battle - 雙人連線搶答遊戲

這是你的雙人單字搶答遊戲網站！支援：
- 雙人連線（自動配對）
- 答題速度給分
- 彩帶/叉叉特效
- 題庫可自訂

## 📦 部署方式（使用 Vercel）

### 1. 上傳到 GitHub
- 將整個專案 zip 解壓縮後，上傳到一個新的 GitHub 倉庫

### 2. 部署到 Vercel
- 登入 https://vercel.com
- 點擊 `New Project` → 選擇你上傳的 GitHub Repo
- 使用預設設定（支援前後端）部署即可！

完成後會產生一個網址：`https://your-game-name.vercel.app` 🎉

## 📁 專案結構

- `client/` - 前端 React 遊戲介面
- `api/socket.js` - 後端 Socket.io Server（Vercel Functions）
- `data/words.js` - 題庫
- `public/` - 圖片、音效、動畫特效

---

你可以根據自己的課程更新題庫或樣式！Have fun 😎
